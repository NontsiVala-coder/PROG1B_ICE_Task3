/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1b_ice_task3;

public class PROG1B_ICE_Task3 {

    public static void main(String[] args) {

        Product[] products = {
            new Clothing("T-Shirt", 500.00),
            new Clothing("Jeans", 800.00),
            new Electronics("Laptop", 15000.00),
            new Electronics("Headphones", 1200.00)
        };

        for (Product product : products) {
            System.out.println(product.name + 
                    " Discounted Price: R" + 
                    product.getDiscountedPrice());
        }
    }
}